window.onload = function() {

	$('.btn-collapse').sideNav();
	
}